﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    class Program
    {
        static void Main(string[] args)
        {
            Apartamento apar1 = new Apartamento();

            apar1.Vender();
            apar1.Vender();
            Console.ReadKey();




        }
    }
}
