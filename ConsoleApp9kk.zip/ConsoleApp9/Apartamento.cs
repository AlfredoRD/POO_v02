﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    public class Apartamento
    {
        private string Direccion;
        private string Color;
        private string Areaconstruccion;
        private int parqueos;
        private int Habitaciones;
        private int Banos;

        public Apartamento(string direccion, string color, string areaconstruccion, int parqueos, int habitaciones, int banos)
        {
            this.Direccion = direccion;
            this.Color = color;
            this.Areaconstruccion = areaconstruccion;
            this.parqueos = parqueos;
            this.Habitaciones = habitaciones;
            this.Banos = banos;
        }

        public Apartamento()
        {
        }

        public void Vender()
        {

            string vender;
            
            Console.WriteLine("Desea vender un apartamento? ponga si, en caso contrario ponga no.");
            vender = Console.ReadLine();
            Console.Clear();
            if (vender == "si")
            {
                Console.WriteLine("Coloque la direccion");
                Direccion = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("Coloque el color");
                Color = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("Coloque el area de construccion");
                Areaconstruccion = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("Coloque cuantos paqueos tiene");
                parqueos = int.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Coloque cuantas habitaciones tiene");
                Habitaciones = int.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Coloque cuantos banos tiene");
                Banos = int.Parse(Console.ReadLine());
                Console.Clear();

                Console.WriteLine($"El apartamento alquilar es: \n Direccion: {Direccion}\n Color:{Color}\n areaconstruccion:{Areaconstruccion}\n Parqueos:{parqueos}\n Habitaciones:{Habitaciones}\n banos:{Banos}");
                Console.ReadKey();
              }
        
         else
            {
                alquilar();
            }
                
        }
        public void alquilar()
        {
            
            string Alquilar;
            Console.WriteLine("Desea alquilar? yes para alquilar, escriba no para cerrar");
            Alquilar = Console.ReadLine();
            if (Alquilar == "yes")
            {
                Console.WriteLine("Coloque la direccion que desea");
                Direccion = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("Coloque el color que desea");
                Color = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("Coloque el area de construccion que desea");
                Areaconstruccion = Console.ReadLine();
                Console.Clear();
                Console.WriteLine("Coloque cuantos paqueos quieres");
                parqueos = int.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Coloque cuantas habitaciones quieres");
                Habitaciones = int.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine("Coloque cuantos banos quieres");
                Banos = int.Parse(Console.ReadLine());
                Console.Clear();
                Console.WriteLine($"El apartamento alquilar es: \n Direccion: {Direccion}\n Color:{Color}\n areaconstruccion:{Areaconstruccion}\n Parqueos:{parqueos}\n Habitaciones:{Habitaciones}\n banos:{Banos}");
                Console.ReadKey();
            }

        
        }
    }
}


